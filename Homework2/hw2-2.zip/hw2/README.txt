### Instructions
Run:
python hw2.py

Uses tf.keras included in Tensorflow 2.0 instead of separate Keras installation.

After running, several windows should display showing live video.
The frame called orig with ROI box should have bounding boxes with predicted digits.
Can show a paper with handwritten digits close to screen.

### Requirements
Python 3.6.6
CV2 4.5.1
Tensorflow 2.0.0

### Libraries
numpy