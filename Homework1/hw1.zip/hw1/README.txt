### Instructions
Run the .ipynb file on Google Colab:
https://colab.research.google.com/drive/1tqhOLLOQdtqrnmSUYZ448AUh0Pk3wdG7?usp=sharing